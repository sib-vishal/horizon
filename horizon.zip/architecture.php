<?php $page = 'home';

$projects = [
    [
        "developer" => "JPV Realtors",
        "location" => "Andheri West",
        "status" => "Completed",
        "design_team" => ["Dharana Shah", "Hiren Cholalia"],
        "project_name" => "Pratap Elegance",
        "category" => "Residential",
        "images" => [
            [
                "thumbnail" => "https://horizonarchitects.co.in/wp-content/uploads/2025/02/6-scaled-500x450.jpg",
                "full" => "https://horizonarchitects.co.in/wp-content/uploads/2025/02/6-1024x670.jpg"
            ],
            [
                "thumbnail" => "https://horizonarchitects.co.in/wp-content/uploads/2025/02/5-scaled-500x450.jpg",
                "full" => "https://horizonarchitects.co.in/wp-content/uploads/2025/02/5-1024x830.jpg"
            ]
        ]
    ],
    [
        "developer" => "Rohan Reality",
        "location" => "Malad",
        "status" => "Completed",
        "design_team" => ["Ar. Akshay Agarwal"],
        "project_name" => "Satsang Bharti",
        "category" => "Residential",
        "images" => [
            [
                "thumbnail" => "https://horizonarchitects.co.in/wp-content/uploads/2025/02/7-scaled.jpg",
                "full" => "https://horizonarchitects.co.in/wp-content/uploads/2025/02/7-scaled.jpg"
            ]
        ]
    ],
    [
        "developer" => "Mukesh Mannat",
        "location" => "Mulund",
        "status" => "On Going",
        "design_team" => ["Dharana Shah", "Hiren Chotalia"],
        "project_name" => "Jaydeep Regalia",
        "category" => "Residential",
        "images" => [
            [
                "thumbnail" => "https://horizonarchitects.co.in/wp-content/uploads/2025/02/8-scaled-500x450.jpg",
                "full" => "https://horizonarchitects.co.in/wp-content/uploads/2025/02/8-1024x661.jpg"
            ],
            [
                "thumbnail" => "https://horizonarchitects.co.in/wp-content/uploads/2025/02/81-scaled-500x450.jpg",
                "full" => "https://horizonarchitects.co.in/wp-content/uploads/2025/02/81-1024x816.jpg"
            ],
            [
                "thumbnail" => "https://horizonarchitects.co.in/wp-content/uploads/2025/02/9-scaled-500x450.jpg",
                "full" => "https://horizonarchitects.co.in/wp-content/uploads/2025/02/9-1024x808.jpg"
            ],
            [
                "thumbnail" => "https://horizonarchitects.co.in/wp-content/uploads/2025/02/10-scaled-500x450.jpg",
                "full" => "https://horizonarchitects.co.in/wp-content/uploads/2025/02/10-1024x621.jpg"
            ]
        ]
    ],
    [
        "developer" => "Woodstock Reality",
        "location" => "Khar",
        "status" => "On Going",
        "design_team" => ["Dharana Shah", "Hiren Chotalia"],
        "project_name" => "Woodstock Reality",
        "category" => "Residential",
        "images" => [
            [
                "thumbnail" => "https://horizonarchitects.co.in/wp-content/uploads/2025/03/11-scaled.jpg",
                "full" => "https://horizonarchitects.co.in/wp-content/uploads/2025/03/11-scaled.jpg"
            ]
        ]
    ],
    [
        "developer" => "Terraform Reality",
        "location" => "Wadala",
        "status" => "On Going",
        "design_team" => ["Hiren Chotalia"],
        "project_name" => "Terraform Reality",
        "category" => "Residential",
        "images" => [

            [
                "thumbnail" => "https://horizonarchitects.co.in/wp-content/uploads/2025/03/12-scaled-500x500.jpg",
                "full" => "https://horizonarchitects.co.in/wp-content/uploads/2025/03/12-1024x847.jpg"
            ],
            [
                "thumbnail" => "https://horizonarchitects.co.in/wp-content/uploads/2025/03/13-scaled-500x500.jpg",
                "full" => "https://horizonarchitects.co.in/wp-content/uploads/2025/03/13-1010x1024.jpg"
            ],
            [
                "thumbnail" => "https://horizonarchitects.co.in/wp-content/uploads/2025/03/14-scaled-500x500.jpg",
                "full" => "https://horizonarchitects.co.in/wp-content/uploads/2025/03/14-1024x781.jpg"
            ]
        ]
    ],
    [
        "developer" => "Mangal Build Home",
        "location" => "Vile Parle",
        "status" => "Ongoing",
        "design_team" => ["Dharana Shah", "Hiren Chotalia", "Dhwani Vaghasiya"],
        "project_name" => "Mangal Signature",
        "category" => "Residential",
        "images" => [
            [
                "thumbnail" => "https://horizonarchitects.co.in/wp-content/uploads/2025/03/15-scaled-600x550.jpg",
                "full" => "https://horizonarchitects.co.in/wp-content/uploads/2025/03/15-scaled-600x550.jpg"
            ]
        ]
    ],
    [
        "developer" => "Bhatia Builders",
        "location" => "Borivali",
        "status" => "Ongoing",
        "design_team" => ["Dharana Shah", "Hiren Chotalia", "Dhwani Vaghasiya"],
        "project_name" => "Espee Square",
        "category" => "Residential",
        "images" => [
            [
                "thumbnail" => "https://horizonarchitects.co.in/wp-content/uploads/2025/03/16-scaled.jpg",
                "full" => "https://horizonarchitects.co.in/wp-content/uploads/2025/03/16-scaled.jpg"
            ]
        ]
    ],
    [
        "developer" => "Atul Builders",
        "location" => "Bhandup",
        "status" => "Ongoing",
        "design_team" => ["Dharana Shah", "Hiren Chotalia"],
        "project_name" => "Atul Horizon",
        "category" => "Commercial",
        "images" => [
            [
                "thumbnail" => "https://horizonarchitects.co.in/wp-content/uploads/2025/03/17-scaled.jpg",
                "full" => "https://horizonarchitects.co.in/wp-content/uploads/2025/03/17-scaled.jpg"
            ]
        ]
    ],
    [
        "developer" => "Mukesh Minat",
        "location" => "Malad",
        "status" => "Ongoing",
        "design_team" => ["Dharana Shah", "Hiren Chotalia", "Dhwani Vaghasiya"],
        "project_name" => "Gami Group Ventura Commercial Hub",
        "category" => "Commercial",
        "images" => [
            [
                "thumbnail" => "https://horizonarchitects.co.in/wp-content/uploads/2025/03/19-scaled-500x420.jpg",
                "full" => "https://horizonarchitects.co.in/wp-content/uploads/2025/03/19-1024x608.jpg"
            ],
            [
                "thumbnail" => "https://horizonarchitects.co.in/wp-content/uploads/2025/03/18-scaled-500x420.jpg",
                "full" => "https://horizonarchitects.co.in/wp-content/uploads/2025/03/18-1024x878.jpg"
            ]
        ]
    ],
    [
        "developer" => "Daiwwik Group",
        "location" => "Goregaon",
        "status" => "Ongoing",
        "design_team" => ["Dharana Shah", "Hiren Chotalia"],
        "project_name" => "Young Man Society",
        "category" => "Commercial",
        "images" => [
            [
                "thumbnail" => "https://horizonarchitects.co.in/wp-content/uploads/2025/03/20-scaled-500x420.jpg",
                "full" => "https://horizonarchitects.co.in/wp-content/uploads/2025/03/20-1024x791.jpg"
            ],
            [
                "thumbnail" => "https://horizonarchitects.co.in/wp-content/uploads/2025/03/21-scaled-500x420.jpg",
                "full" => "https://horizonarchitects.co.in/wp-content/uploads/2025/03/21-1024x616.jpg"
            ]
        ]
    ],
    [
        "developer" => "Ossia Developers",
        "location" => "Borivali",
        "status" => "Ongoing",
        "design_team" => ["Dharana Shah", "Hiren Chotalia", "Dhwani Vaghasiya"],
        "project_name" => "Shiv Sadan",
        "category" => "Commercial",
        "images" => [
            [
                "thumbnail" => "https://horizonarchitects.co.in/wp-content/uploads/2025/03/23-scaled-500x420.jpg",
                "full" => "https://horizonarchitects.co.in/wp-content/uploads/2025/03/23-1024x699.jpg"
            ],
            [
                "thumbnail" => "https://horizonarchitects.co.in/wp-content/uploads/2025/03/22-scaled-500x420.jpg",
                "full" => "https://horizonarchitects.co.in/wp-content/uploads/2025/03/22-1024x847.jpg"
            ]
        ]
    ],
    [
        "developer" => "Madhu Developers",
        "location" => "Goregaon",
        "status" => "Ongoing",
        "design_team" => ["Dharana Shah", "Hiren Chotalia", "Dhwani Vaghasiya"],
        "project_name" => "Madhu Estate",
        "category" => "Commercial",
        "images" => [
            [
                "thumbnail" => "https://horizonarchitects.co.in/wp-content/uploads/2025/03/24-scaled.jpg",
                "full" => "https://horizonarchitects.co.in/wp-content/uploads/2025/03/24-scaled.jpg"
            ]
        ]
    ],
    [
        "developer" => "Mangal Build Home",
        "location" => "Chembur",
        "status" => "Completed",
        "design_team" => ["Dharana Shah", "Hiren Chotalia", "Dhwani Vaghasiya"],
        "project_name" => "Mangal Smriti",
        "category" => "Mixed Use",
        "images" => [
            [
                "thumbnail" => "https://horizonarchitects.co.in/wp-content/uploads/2025/03/1-scaled-500x420.jpg",
                "full" => "https://horizonarchitects.co.in/wp-content/uploads/2025/03/1-802x1024.jpg"
            ],
            [
                "thumbnail" => "https://horizonarchitects.co.in/wp-content/uploads/2025/03/2-scaled-500x420.jpg",
                "full" => "https://horizonarchitects.co.in/wp-content/uploads/2025/03/2-857x1024.jpg"
            ]
        ]
    ]
];




$chunks = array_chunk($projects, ceil(count($projects) / 3));
?>



<!DOCTYPE html>
<html lang="en">

<head>
    <title>Horizon Architects - Welcome to Our Website </title>
    <?php include 'include/head-links.php'; ?>
    <meta property="og:url" content="<?php echo $page_url ?>">
    <meta property="og:title" content="">
    <meta property="og:description" content="">
    <meta property="og:image" content="images/logo.png">
    <meta name="twitter:card" content="">
    <meta name="twitter:site" content="<?php echo $page_url ?>">
    <meta name="twitter:title" content="">
    <meta name="twitter:description" content="">
    <meta name="twitter:image" content="images/logo.png">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css" />

</head>

<body onload="createCaptcha();">
    <div class="wrapper ">
        <?php include 'include/header.php'; ?>

        <div class="banner_page  ">
            <div class="containerFull">
                <div class="inner_banner_page ">
                    <div class="inner_banner_page_content">

                        <h4 class="heading fontHeading fontWeight600">
                            Architecture --
                        </h4>

                    </div>

                </div>

            </div>

        </div>
    </div>
    <section>
        <div class="containerFull">
            <ul class="nav nav-pills architecture_btn nav-fill col-lg-6" id="myTab" role="tablist">
                <li class="nav-item" role="presentation">
                    <button class="nav-link fontWeight600 fontHeading active" id="residential-tab" data-bs-toggle="tab"
                        data-bs-target="#residential" type="button" role="tab" aria-controls="residential"
                        aria-selected="true">Residential</button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link fontWeight600 fontHeading" id="commercial-tab" data-bs-toggle="tab"
                        data-bs-target="#commercial" type="button" role="tab" aria-controls="commercial"
                        aria-selected="false">Commercial</button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link fontWeight600 fontHeading" id="mixed-use-tab" data-bs-toggle="tab"
                        data-bs-target="#mixed-use" type="button" role="tab" aria-controls="mixed-use"
                        aria-selected="false">Mixed Use</button>
                </li>
            </ul>
            <hr />

            <!-- Tab Content -->
            <div class="tab-content mt-3" id="myTabContent">
                <div class="tab-pane fade show active" id="residential" role="tabpanel"
                    aria-labelledby="residential-tab">
                    <div class="architecture_grid">
                        <?php foreach ($chunks as $chunkIndex => $chunk): ?>
                            <!-- <div> -->
                            <?php foreach ($chunk as $index => $project): ?>
                                <?php $loopIndex = $chunkIndex . '-' . $index; // Ensure unique modal ID ?>
                                <?php if ($project['category'] === 'Residential'): ?>

                                    <div class="item_grid mb-3  " data-aos="fade-up" data-aos-offset="100">
                                        <div class="item_grid_inner">
                                            <img src="<?php echo isset($project['images'][0]['full']) ? htmlspecialchars($project['images'][0]['full']) : 'placeholder.jpg'; ?>"
                                                class="img-fluid" loading="lazy"
                                                alt="<?php echo htmlspecialchars($project['project_name']); ?>" />
                                        </div>
                                        <div class="content">
                                            <div>
                                                <h5 class="sub_heading fontHeading fontWeight600 text-white">
                                                    <?php echo htmlspecialchars($project['project_name']); ?>
                                                </h5>
                                                <button type="button" class="" data-bs-toggle="modal"
                                                    data-bs-target="#projectModal<?php echo $loopIndex; ?>">
                                                    Click Here
                                                </button>
                                            </div>
                                        </div>
                                    </div>

                                    <!-- Bootstrap Modal -->
                                    <div class="modal fade model-xl" id="projectModal<?php echo $loopIndex; ?>" tabindex="-1"
                                        aria-labelledby="projectModalLabel<?php echo $loopIndex; ?>" aria-hidden="true">
                                        <div class="modal-dialog modal-dialog-centered modal-dialog modal-xl ">
                                            <div class="modal-content">
                                                <div class="row">
                                                    <div class="col-lg-6">
                                                        <div class="swiper architecture_slider">
                                                            <div class="swiper-wrapper">
                                                                <?php foreach ($project['images'] as $image): ?>
                                                                    <div class="swiper-slide">

                                                                        <img src="<?php echo htmlspecialchars($image['full']); ?>"
                                                                            class="img-fluid"
                                                                            alt="<?php echo htmlspecialchars($project['project_name']); ?>" />

                                                                    </div>
                                                                <?php endforeach; ?>
                                                            </div>

                                                        </div>


                                                    </div>
                                                    <div class="col-lg-6">
                                                        <div class="modal-header">
                                                            <h5 class="modal-title small_heading text_primary"
                                                                id="projectModalLabel<?php echo $loopIndex; ?>">
                                                                <?php echo htmlspecialchars($project['project_name']); ?>
                                                            </h5>
                                                            <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                                aria-label="Close"></button>
                                                        </div>
                                                        <div class="modal-body">
                                                            <div class="item_details">
                                                                <div class="icon">
                                                                    <svg stroke="currentColor" fill="currentColor" stroke-width="0"
                                                                        viewBox="0 0 448 512" height="1em" width="1em"
                                                                        xmlns="http://www.w3.org/2000/svg">
                                                                        <path
                                                                            d="M313.6 304c-28.7 0-42.5 16-89.6 16-47.1 0-60.8-16-89.6-16C60.2 304 0 364.2 0 438.4V464c0 26.5 21.5 48 48 48h352c26.5 0 48-21.5 48-48v-25.6c0-74.2-60.2-134.4-134.4-134.4zM400 464H48v-25.6c0-47.6 38.8-86.4 86.4-86.4 14.6 0 38.3 16 89.6 16 51.7 0 74.9-16 89.6-16 47.6 0 86.4 38.8 86.4 86.4V464zM224 288c79.5 0 144-64.5 144-144S303.5 0 224 0 80 64.5 80 144s64.5 144 144 144zm0-240c52.9 0 96 43.1 96 96s-43.1 96-96 96-96-43.1-96-96 43.1-96 96-96z">
                                                                        </path>
                                                                    </svg>

                                                                </div>
                                                                <div class="item_content">
                                                                    <small>
                                                                        Developer
                                                                    </small>
                                                                    <h5>
                                                                        <?php echo htmlspecialchars($project['developer'] ?? 'N/A'); ?>

                                                                    </h5>
                                                                </div>


                                                            </div>
                                                            <div class="item_details">
                                                                <div class="icon">
                                                                    <svg stroke="currentColor" fill="currentColor" stroke-width="0"
                                                                        viewBox="0 0 24 24" height="1em" width="1em"
                                                                        xmlns="http://www.w3.org/2000/svg">
                                                                        <path fill="none" stroke-width="2"
                                                                            d="M12,22 C12,22 4,16 4,10 C4,5 8,2 12,2 C16,2 20,5 20,10 C20,16 12,22 12,22 Z M12,13 C13.657,13 15,11.657 15,10 C15,8.343 13.657,7 12,7 C10.343,7 9,8.343 9,10 C9,11.657 10.343,13 12,13 L12,13 Z">
                                                                        </path>
                                                                    </svg>

                                                                </div>
                                                                <div class="item_content">
                                                                    <small>
                                                                        Location
                                                                    </small>
                                                                    <h5>
                                                                        <?php echo htmlspecialchars($project['location'] ?? 'N/A'); ?>

                                                                    </h5>
                                                                </div>


                                                            </div>
                                                            <div class="item_details">
                                                                <div class="icon">
                                                                    <svg stroke="currentColor" fill="currentColor" stroke-width="0"
                                                                        viewBox="0 0 24 24" height="1em" width="1em"
                                                                        xmlns="http://www.w3.org/2000/svg">
                                                                        <path fill="none" stroke-width="2"
                                                                            d="M2,3.99079514 C2,2.89130934 2.89821238,2 3.99079514,2 L20.0092049,2 C21.1086907,2 22,2.89821238 22,3.99079514 L22,20.0092049 C22,21.1086907 21.1017876,22 20.0092049,22 L3.99079514,22 C2.89130934,22 2,21.1017876 2,20.0092049 L2,3.99079514 Z M12,15 L12,14 C12,13 12,12.5 13,12 C14,11.5 15,11 15,9.5 C15,8.5 14,7 12,7 C10,7 9,8.26413718 9,10 M12,16 L12,18">
                                                                        </path>
                                                                    </svg>

                                                                </div>
                                                                <div class="item_content">
                                                                    <small>
                                                                        Status
                                                                    </small>
                                                                    <h5>
                                                                        <?php echo htmlspecialchars($project['status'] ?? 'N/A'); ?>

                                                                    </h5>
                                                                </div>


                                                            </div>
                                                            <div class="item_details">
                                                                <div class="icon">
                                                                    <svg stroke="currentColor" fill="currentColor" stroke-width="0"
                                                                        viewBox="0 0 1024 1024" height="1em" width="1em"
                                                                        xmlns="http://www.w3.org/2000/svg">
                                                                        <path
                                                                            d="M824.2 699.9a301.55 301.55 0 0 0-86.4-60.4C783.1 602.8 812 546.8 812 484c0-110.8-92.4-201.7-203.2-200-109.1 1.7-197 90.6-197 200 0 62.8 29 118.8 74.2 155.5a300.95 300.95 0 0 0-86.4 60.4C345 754.6 314 826.8 312 903.8a8 8 0 0 0 8 8.2h56c4.3 0 7.9-3.4 8-7.7 1.9-58 25.4-112.3 66.7-153.5A226.62 226.62 0 0 1 612 684c60.9 0 118.2 23.7 161.3 66.8C814.5 792 838 846.3 840 904.3c.1 4.3 3.7 7.7 8 7.7h56a8 8 0 0 0 8-8.2c-2-77-33-149.2-87.8-203.9zM612 612c-34.2 0-66.4-13.3-90.5-37.5a126.86 126.86 0 0 1-37.5-91.8c.3-32.8 13.4-64.5 36.3-88 24-24.6 56.1-38.3 90.4-38.7 33.9-.3 66.8 12.9 91 36.6 24.8 24.3 38.4 56.8 38.4 91.4 0 34.2-13.3 66.3-37.5 90.5A127.3 127.3 0 0 1 612 612zM361.5 510.4c-.9-8.7-1.4-17.5-1.4-26.4 0-15.9 1.5-31.4 4.3-46.5.7-3.6-1.2-7.3-4.5-8.8-13.6-6.1-26.1-14.5-36.9-25.1a127.54 127.54 0 0 1-38.7-95.4c.9-32.1 13.8-62.6 36.3-85.6 24.7-25.3 57.9-39.1 93.2-38.7 31.9.3 62.7 12.6 86 34.4 7.9 7.4 14.7 15.6 20.4 24.4 2 3.1 5.9 4.4 9.3 3.2 17.6-6.1 36.2-10.4 55.3-12.4 5.6-.6 8.8-6.6 6.3-11.6-32.5-64.3-98.9-108.7-175.7-109.9-110.9-1.7-203.3 89.2-203.3 199.9 0 62.8 28.9 118.8 74.2 155.5-31.8 14.7-61.1 35-86.5 60.4-54.8 54.7-85.8 126.9-87.8 204a8 8 0 0 0 8 8.2h56.1c4.3 0 7.9-3.4 8-7.7 1.9-58 25.4-112.3 66.7-153.5 29.4-29.4 65.4-49.8 104.7-59.7 3.9-1 6.5-4.7 6-8.7z">
                                                                        </path>
                                                                    </svg>

                                                                </div>
                                                                <div class="item_content">
                                                                    <small>
                                                                        Design Team
                                                                    </small>
                                                                    <h5>
                                                                        <?php echo !empty($project['design_team']) ? htmlspecialchars(implode(", ", $project['design_team'])) : 'N/A'; ?>

                                                                    </h5>
                                                                </div>


                                                            </div>


                                                        </div>
                                                    </div>

                                                </div>


                                            </div>
                                        </div>
                                    </div>
                                <?php endif; ?>

                            <?php endforeach; ?>
                            <!-- </div> -->
                        <?php endforeach; ?>

                    </div>
                </div>
                <div class="tab-pane fade" id="commercial" role="tabpanel" aria-labelledby="commercial-tab">
                    <p>This is the Commercial tab content.</p>
                </div>
                <div class="tab-pane fade" id="mixed-use" role="tabpanel" aria-labelledby="mixed-use-tab">
                    <p>This is the minxed tab content.</p>
                </div>
            </div>

        </div>
    </section>


    <?php include 'include/footer.php'; ?>

    </div>
    <?php include 'include/footer-links.php'; ?>
    <script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>
    <script>
        var swiper = new Swiper('.architecture_slider', {
            loop: true,
            pagination: {
                el: '.swiper-pagination',
                clickable: true,
            },
            navigation: {
                nextEl: '.swiper-button-next',
                prevEl: '.swiper-button-prev',
            },
            autoplay: {
                delay: 3000,
                disableOnInteraction: false,
            },
        });

    </script>





</body>

</html>